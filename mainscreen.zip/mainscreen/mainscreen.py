import pygame
class TitleScreen:
	def __init__(self, gamedisplay):
		self.gamedisplay = gamedisplay()
		self.StevenCarx = -50
		self.ColinCarx = 1850
		self.stevenimage = pygame.image.load("steven_police.png")
	def menu_loop(self):
		self.gamedisplay.bit(self.stevenimage,(StevenCarx, y))		
		quit = False
		while not quit:
			for i in range(10)
				StevenCarx += 10
				self.gamedisplay.blit(self.stevenimage, (StevenCarx, y)
		while quit:
			break
		
